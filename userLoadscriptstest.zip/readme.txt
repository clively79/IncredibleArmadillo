In the beginning the Universe was created.
This had made many people very angry, and has been widely regarded as a bad move.